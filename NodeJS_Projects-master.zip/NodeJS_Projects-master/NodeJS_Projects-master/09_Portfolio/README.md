# NodeJs Projects
## Project#09: Portfolio

- NodeJs + Express + MySQL + PHPMyAdmin
- Using Custome Theme Starter Bootstrap.
- Using Multer for Image Uploads.
- Adding Simple CRUD for new Projects.


Final Show Case
![VIEWS](https://github.com/MAshrafM/NodeJS_Projects/blob/master/09_Portfolio/show.jpg)

### Future
- Adding login System to the Admin.
- Adding latest news and feed.
- Add A Blog.
- Use Custome Theme.